var express = require("express");
//console.log("Let's find out what express is", express);
// invoke express and store the result in the variable app
var session = require('express-session');
var bodyParser = require('body-parser');
var app = express();
var mongoose = require('mongoose');

app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(session({
    secret: 'secretKey',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));
app.use(bodyParser.urlencoded({ extended: true }));
const flash = require('express-flash');
app.use(flash());
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost/login_and_registration', { useNewUrlParser: true });
const bcrypt = require('bcryptjs');
var mongoose = require('mongoose');
var uniqueValidator = require('mongoose-unique-validator');

var validateEmail = function(email) { //this is the function for the email validation and match in the UserSchema below
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return re.test(email)
};



var UserSchema = new mongoose.Schema({
    email:{type: String, required: true, unique: true, minlength: 2, validate: [validateEmail, 'Please fill a valid email address'],
    match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please fill a valid email address']},
    first_name:{type: String, required: true, minlength: 2},
    last_name:{type: String, required: true, minlength: 2},
    password: {type: String, required: true, minlength: 2},
    birthday: {type: Date, required: true, minlength: 2},
    },{ timestamps:true });

UserSchema.pre('save', function (next){ //pre function for password hashing, will not show up in request.body
    bcrypt.hash(this.password, 10)
    .then(hashed_password => {
        this.password=hashed_password;
        next();
    })
    .catch(error => {
        console.log(error);
    });
})
    
UserSchema.plugin(uniqueValidator);

mongoose.model("User", UserSchema);
var User = mongoose.model("User");

app.get('/', function(request, response){
    User.find({}, function(err, users){
        //console.log(users);
    })
    response.render('index'); 
});

app.post('/register', function(request, response){
    
    console.log("ADD: ", request.body);
    var new_user = new User({
        email: request.body.email,
        first_name: request.body.first_name,
        last_name: request.body.last_name,
        password: request.body.password,
        birthday: request.body.birthday,
    });
    new_user.save(function(error){
        if(error){
            for(var key in error.errors){
                request.flash('registration', error.errors[key].message);
            }
            response.redirect('/');
        } 
        else {
            console.log('success from add POST SAVE message');
            request.session.first_name=new_user.first_name;
            request.session.id=new_user._id;
            response.redirect('/success');
        }
    })
    console.log(new_user)
            
});

app.post('/login', function(request, response){
    User.findOne({email: request.body.email}, function(err, user){
        if(err) {
            console.log("can't login");
            response.redirect('/')
        } else {
            if(user){
                const dbPassword = user.password;
                bcrypt.compare(request.body.password, dbPassword)
                .then( result => {
                    request.session.first_name=user.first_name;
                    request.session.id=user.id;
                    response.redirect('/success')
                })
                .catch( error => {
                     console.log(error);
                     response.redirect('/')
                })
                
               
                
            } else {
                console.log("user doesnt exist");
                response.redirect('/')
            } 
        } 
    })         
});

app.get('/success', function(request, response){

    response.render('success', {session:request.session}); 
});

app.get('/logout', function(request, response){
    request.session.destroy();
    console.log('Succesful Logout')
    response.redirect('/'); 
});


    // tell the express app to listen on port 8000, always put this at the end of your server.js file
    app.listen(8000, function () {
        console.log("listening on port 8000");
    })

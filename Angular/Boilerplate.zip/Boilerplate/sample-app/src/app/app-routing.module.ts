import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreateComponent } from './create/create.component';
import { EditComponent } from './edit/edit.component';
import { ShowComponent } from './show/show.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';

const routes: Routes = [
  { path: 'pets',component: HomeComponent },
  { path: '', pathMatch: 'full', redirectTo: '/pets' },
  { path: 'pets/new',component: CreateComponent },
  { path: 'pets/:id/edit',component: EditComponent },
  { path: 'pets/:id',component: ShowComponent },
  { path: '**', component: PagenotfoundComponent }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router} from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})

export class EditComponent implements OnInit {
  editTask={ name: "", type: "", description: "", skill1: "", skill2: "", skill3: "" } ;
  tasks = [];
  idToEdit='';
  shown: Object;
  error = {};
  constructor(private _route: ActivatedRoute, private _httpService: HttpService, private _router: Router) { }
  
  goHome() {
    this._router.navigate(['/']);
  }

  ngOnInit() {
    this._route.params.subscribe((params: Params) => {
      this.idToEdit = params['id'];
      this.getTask();
    })
  }
  getTask(){
    let observable = this._httpService.getTask(this.idToEdit);
    observable.subscribe(data => {
      console.log('got task: ', data)
      this.editTask = data['task'];
    })
  }

  onEdit() {  //on submission of the form, send editTask to the database and update the task based on ID
    console.log(this.editTask);
    let observable = this._httpService.editTask(this.editTask);
    observable.subscribe(data => {
      //console.log(data);
      if (data['errors']) {
        this.error=data['errors'];
      }
      else {
        this.goHome();
      }
      console.log(this.tasks)
    })
  };

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  constructor(private _http: HttpClient) {
    this.getTasks();
  }
  getTasks() { 
    return this._http.get('/api/pets');
  }
  addTask(newtask) {
    return this._http.post('/pet', newtask)
  }

  getTask(id){
    return this._http.get('/pet/'+id);
  }
  
  editTask(editTask) {
    //console.log(editTask)
    return this._http.put(`/pet/${editTask._id}`, editTask)
  }

  deleteTask(deleteTask) {
    //console.log(editTask)
    return this._http.delete(`/pet/${deleteTask._id}`, deleteTask)
  }

  // likePet(id){
  //   return this._http.put('/api/pets/like/'+id, id);
  // }

}
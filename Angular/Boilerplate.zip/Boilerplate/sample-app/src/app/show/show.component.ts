import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router} from '@angular/router';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  showTask={ name: "", type: "", description: "", skill1: "", skill2: "", skill3: "", likes: 0 };
  deleteTask={ _id: "", name: "", type: "", description: "", skill1: "", skill2: "", skill3: "", likes: 0 } ;
  tasks = [];
  //likes=0;
  idToShow='';
  shown: Object;
  error = {};
  constructor(private _route: ActivatedRoute, private _httpService: HttpService, private _router: Router) { }

  goHome() {
    this._router.navigate(['/']);
  }

  ngOnInit() {
    this._route.params.subscribe((params: Params) => {
      this.idToShow = params['id'];
      this.getTask();
    })
  }
  getTask(){
    let observable = this._httpService.getTask(this.idToShow);
    observable.subscribe(data => {
      
      this.showTask = data['task'];
      console.log('got task: ', this.showTask)
    })
  }
  onDelete(showTask) {  
    this.deleteTask={_id: this.idToShow, name: showTask.name, type: showTask.title, description: showTask.description, skill1: showTask.skill1, skill2: showTask.skill2, skill3: showTask.skill3, likes: showTask.likes};
    let observable = this._httpService.deleteTask(this.deleteTask);
    observable.subscribe(data => {
      for (var i=0;i< this.tasks.length; i++) { //this edits the tasks without a refresh by updating the tasks array (Defined above)
        if(this.tasks[i]['_id'] == this.deleteTask._id) {
          this.tasks.splice(i,1); //removes array element starting at index i and for 1 value (only that index)
        }
      }
      this.goHome();
    });
  }

  // likePet(){
  //   let observable = this._httpService.likePet(this.idToShow);
  //   observable.subscribe(data => {
  //     //console.log('deleted pet')
  //     //this.getTask()
  //     this.showTask['likes']+=1;
  //   })
  // }

}

import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private _httpService: HttpService) { }
  tasks = [];
  deleteTask={_id:'', title: '', description: ''};

  ngOnInit() {
    this.getTasksFromService();
  }
  getTasksFromService() { //gets tasks from the root route and pushes them into an array (which can be added to HTML)
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Got our tasks!", data)
      for (var task in data) {
        this.tasks.push(data[task]);
      }
    })};
  onDelete(task) {  
    this.deleteTask={_id:task._id, title: task.title, description: task.description};
    let observable = this._httpService.deleteTask(this.deleteTask);
    observable.subscribe(data => {
      for (var i=0;i< this.tasks.length; i++) { //this edits the tasks without a refresh by updating the tasks array (Defined above)
        if(this.tasks[i]['_id'] == this.deleteTask._id) {
          this.tasks.splice(i,1); //removes array element starting at index i and for 1 value (only that index)
        }
      }

    });
}

}
